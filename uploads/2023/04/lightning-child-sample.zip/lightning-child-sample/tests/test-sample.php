<?php
/**
 * Class SampleTest
 *
 * @package Lightning_Customize_Plugin
 */

/**
 * Sample test case.
 */
class SampleTest extends WP_UnitTestCase {

	/**
	 * A single example test.
	 */
	public function test_sample() {
		// Replace this with some actual testing code.
		$return = 'aaa';
		$this->assertEquals( 'aaa', $return );
	}
}
